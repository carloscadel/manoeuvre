// COOL ANIMATION
// var planet = new Sphere(ctx, canvas.width/2, canvas.height/2, 75, 0, 0, 'rgb(0, 127, 127)')
// var satellite1 = new Sphere(ctx, canvas.width/2 - 100, canvas.height/2 - 100, 10, 1, -3, 'white')
// var satellite2 = new Sphere(ctx, canvas.width/2 - 100, canvas.height/2 + 100, 10, 3, 1, 'orange')
// var satellite3 = new Sphere(ctx, canvas.width/2 + 100, canvas.height/2 + 100, 10, -1, 3, 'green')
// var satellite4 = new Sphere(ctx, canvas.width/2 + 100, canvas.height/2 - 100, 10, -3, -1, 'yellow')